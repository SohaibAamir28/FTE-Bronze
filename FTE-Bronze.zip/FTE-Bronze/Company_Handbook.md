# Company Handbook

## Agent Skill: Process Task

Trigger: 'Process Task'

When this trigger is activated, the following sequence will execute:

1.  **Read Files:** Read all Markdown files inside the `Needs_Action` folder.
2.  **Analyze Context:** Understand the context of each file and mark its internal status as 'Completed'.
3.  **Archive Task:** Move the processed Markdown file into the `Done` folder.
4.  **Update Dashboard:** Update `Dashboard.md` by:
    *   Moving the task name from the 'Pending Tasks' section to the 'Completed Tasks' section.
5.  **Log Activity:** Append a short entry to `System_Logs.md` detailing the processed tasks and actions taken.
