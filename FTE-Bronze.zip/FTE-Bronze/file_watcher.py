import os
import time
import shutil

INBOX_DIR = "Inbox"
NEEDS_ACTION_DIR = "Needs_Action"

def process_inbox():
    # Loop over files in Inbox
    for filename in os.listdir(INBOX_DIR):
        inbox_path = os.path.join(INBOX_DIR, filename)

        # Only process files, not directories
        if os.path.isfile(inbox_path):
            # Create a Markdown version in Needs_Action
            md_filename = os.path.splitext(filename)[0] + ".md"
            target_path = os.path.join(NEEDS_ACTION_DIR, md_filename)

            # Simple deduplication: Check if it's already in Needs_Action
            if not os.path.exists(target_path):
                with open(inbox_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                with open(target_path, 'w', encoding='utf-8') as f:
                    f.write(f"# Task: {md_filename}\n")
                    f.write(f"Source: {filename}\n")
                    f.write("Status: Pending\n\n")
                    f.write("## Content\n")
                    f.write(content)

                print(f"Processed: {filename} -> {md_filename}")
            else:
                print(f"Skipping: {md_filename} already exists in {NEEDS_ACTION_DIR}")

            # To avoid re-processing the same file in the next loop,
            # we should move or delete the original from Inbox.
            # I'll move it to Done/Originals for safekeeping or just delete.
            # Following the prompt "avoid duplicating tasks", I'll move it to Done.
            os.makedirs("Done/Originals", exist_ok=True)
            shutil.move(inbox_path, os.path.join("Done/Originals", filename))

if __name__ == "__main__":
    print(f"Monitoring {INBOX_DIR} for new files...")
    while True:
        process_inbox()
        time.sleep(5)
